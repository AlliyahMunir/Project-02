#include <iostream>
#include <string>
#include <vector>
using namespace std;
int main() {
  //we are using vectors so we include vectors at the top
    // Array of string objects
    //we create a string of 10 due to ten lines of output printed
    string arr[10] = {
      //We will be displaying the opened hours of the restaurant
        "\n\nThe Authentic Burger and Bakery Restaurant\n",
        "             Opened Hours",
        "-----------------------------------------",
        "Monday:       6:00P.M.-11:30 P.M.\n\n",
        "Tuesday:      6:00P.M.-11:30 P.M.\n\n",
        "Wednesday:    6:00P.M.-11:30 P.M.\n\n",
        "Thursday:     6:00P.M.-11:30 P.M.\n\n",
        "Friday:       6:00P.M.-1:30  A.M.\n\n", 
        "Saturday:     6:00P.M.-3:00  A.M.\n\n",  
        "Sunday:       6:00P.M.-1:30  A.M.\n\n",
    };

    // Vector with a string array
    vector < string > vecOfStr(arr, arr +
        sizeof(arr) / sizeof(string));
        //use a for loop to execute the cout statement of days
    for (string days: vecOfStr)
        cout  << days << endl;

    return 0;
}