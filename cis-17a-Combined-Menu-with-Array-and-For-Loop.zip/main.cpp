#include<iostream>
using namespace std;
int main() {//for the menu we will use an Array//the array will be a string array because we are using words addn the alphabet not numbers
//we will make the array set to 20 because we have at least 20 lines displayed
   string Array[20] = {"      The Authentic Burger and Bakery Restaurant Menu", "----------------------------------------------------------------------","       Forget the Diet, Have a Burger & Dessert Tonight!\n","Dinner Options:                                       Price:\n", "Build-Your-Own-Burger(Create through our link!)           $8.99\n" "Old-Fashion Beef Burger                                   $7.99\nDouble Patty Beef Burger                                  $8.99\nThe Original Chicken Burger                               $6.99\nCheesy Overload Chicken Burger                            $7.50\nCheesy Overload Beef Burger                               $7.50\nAll-Time Favorite Vegan Burger                            $6.99", "----------------------------------------------------","Combo Options:                                       Price:\n", "Two Burgers + One Small Drink + Side                    $12.99\n" "One Burger + Side                                       $8.99\nBurger + Two Sides                                      $10.99\n-----------------------------------------------------", "Sides (Choose One per Combo or $3.99 Individually):\n\nCurly Fries                         \nSweet Potato Fries\nNachos with Cheese\nOnion Rings\nColeslaw\nMashed Potatoes","----------------------------------------------------","Beverages:\n                                                      Price:\nPepsi                                                      $1.99\nFanta                                                      $1.99\nCoca-Cola                                                  $1.99\nRoot-Beer                                                  $1.99\n7 Up                                                       $1.99\nChocolate Milkshake(Medium)                                $2.50    \nVanilla Milkshake(Medium)                                  $2.50         \nStrawberry Milkshake(Medium)                               $2.50\nCup of Black Coffee                                        $1.00\nIced Frappuccino(Medium)                                   $3.00\nGreen Tea                                                  $1.50\nBlack Tea                                                  $1.50\n                       ", "---------------------------------------------\n"       "Desserts:                                            Price:\n\nBrownies(5)                                                $4.00\nIce-Cream(Flavors: Vanilla/Chocolate/Strawberry/Mint/Oreo) $3.99\nCheesecake(Vanilla, Oreo Cream, Salted Caramel,\nWhite Chocolate, Raspberry, Tiramisu)                      $5.99\nCreme Brulee                                               $3.99\nRed-Velvet Cake                                            $3.99\nChocolate Chip Cookie Pie                                  $5.99    \nChocolate Mousse(Medium)                                   $2.99        \nMacaroons(3)                                               $4.50\nIce-Cream Sundae(Limit: 3 Flavors)                         $6.99\nTapioca Pudding                                            $3.00\nStrawberry-Filled Crepes(3)                                $5.50\nFruit Platter(Medium)                                      $5.50\n     ",









                  "       The Authentic Burger and Bakery Restaurant\n----------------------------------------------------------------\n"
                  "        Build-Your-Own-Burger Menu(Fixed Price: $8.99)",
      "\nMeat:   Fish     Beef       Chicken   Vegan\n\n",    
      "Dressings(Choose 3 Max): Ranch    Ketchup    Hot Sauce     Garlic Sauce  Mayonnaise\n\n",
      "Toppings(Choose 5 Max):  Lettuce   Tomato Cheese  Avocado   Cucumber\n\n"   
   }; 
   //because we are using an array we are required to add a for loop and cout the array
   for (int i = 0; i < 20; i++)
      cout << Array[i] << endl;

}