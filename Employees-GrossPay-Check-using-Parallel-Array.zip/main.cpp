#include <iostream>
#include<cmath>
#include<iomanip>
//This program allows employees to input pay and tips to keep track for weekly checks
//use cmath to calculate the total amount of check 
//use iomanip for setprecision and having an appropriate grosspay that is exact
using namespace std;

int main()
{
  //we are only allowing three employees to check in per program
  //to keep it simple 
   const int EMPLOYEES_PAY = 3;
   //the line below allows users to input the number of hours they have worked. This line outputs three times in order for each of the 3 employees to input their hours 
   int hours[EMPLOYEES_PAY];
   //we use double for tips because employees will need to use Us Dollar form which may include cents in the tips
   double tips[EMPLOYEES_PAY];
   //we want to warn employees that this is only for employees
  cout<<"\n\n       CAUTION: THIS PROGRAM IS BUILT FOR EMPLOYEES USE ONLY\n\n                 PLEASE EXIT IF YOU ARE A CUSTOMER\n--------------------------------------------------------------\n"<<endl;
   cout<<"Enter the number of hours "<<EMPLOYEES_PAY<<" employees worked this week, to determine pay rate.\n"<<endl;
//use the for loop due to the use of an array
for(int index = 0; index < EMPLOYEES_PAY; index++)
{
  cout<<"Enter the number of hours worked by employee # "<<(index+1)<<" this week : ";
  cin>>hours[index];
 cout<<"Enter the dollar amount that employee # "<<(index+1)<<" has received in tips this week\n(Enter 0 if none): $ ";
 cin>>tips[index];

  }
  //we will setting precision to 2 to make sure that the numbers after the decimal is accurate in US dollar form 
  cout<<"\nBelow is the total pay each employee will receive by the end of the week:\n"<<fixed<<showpoint<<setprecision(2);
  //use the for loop to include the pay for each employee
  for(int index = 0; index < EMPLOYEES_PAY;index++)
  {
    //the wage paid to each employee is $14.75 per hour
    double weeklyPay = (hours[index]*14)+tips[index];
    cout<<"Employee #"<<(index +1);
    //we use fixed showpoint to make sure the wekklyPay that is outputted for the user is accurate in US Dollar form 
    cout<<": $ "<<weeklyPay<<fixed<<showpoint<<setprecision(2)<<"\n"<<endl;
  }
  //at my restaurant the check INCLUDES the tips 
  //at the end, we are reminding employees to make sure their check matches
      cout<<"\nMake sure that the grossPay matches the check you are receiving this week!\n"<<endl;
  return 0;
    }
