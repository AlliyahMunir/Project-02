//this is a receipt for the customer 
#include <iostream>
#include<iomanip>
//use iomanip because we are using numbers 
#include <cmath>
//use c math because we are using numbers with decimals and making calculations
using namespace std;
int main() {
  int count = 1;
  int yes;
  //the rest are double because four digit numbers and decimals may be required
  double tip;
  double dollars;
  double tax;
  double total;
  //we use a do while loop to ensure that the user inputs total correctly and is asked 
  //about tip and tax is calculated
  do{
  cout<<"Enter your total: $ ";
  cin>>total;
  }
  while(count < 1);
  //tax in the us is approx 7.25% of your total
  tax = (0.072*total)+ total;
  cout << "With tax, your total is $"<<setprecision(4)<< tax <<endl;
  //we wait for user to enter 1 or 2
 cout<<"Would you like to give a tip?(Enter 1 for yes and 2 for no) ";
 cin>>tip;
 //create if else statement for whether the user enters 1 or  2 and which statement
//will be outputted
 if(tip==1){
 cout<<"How many dollars would you like to tip? $";
 cin>>setprecision(4)>>dollars;
total = dollars + tax;
 cout<<"Your official total will be $"<<setprecision(4)<<total<<endl;
 }
else {
 cout<<"Alright, your official total will be $"<<setprecision(4)<<tax<<endl;
 }
  return 0;
}