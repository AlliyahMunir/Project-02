//pouinters will be passing c-string arguments
#include <iostream>
#include<cstring>
using namespace std;

int main(){
  const int LENGTH = 200;
  //we will be using two arrays
  char firstString[LENGTH], secondstring[LENGTH];
        cout << "\n\nEnter your name: ";
    cin.getline(firstString, LENGTH);
  cout<<"\nBegin writing your review and please keep it under 200 wordss, then press Enter:"<<endl;
  cin.getline(secondstring, LENGTH);

//use the if-else statement to make sure user enters review correctly 
//use strcmp function which is case sensitive when compared to strings
  if (strcmp(firstString, secondstring)==0)
  cout<<"You seem to have entered your name and/or your review twice. Please try again. \n"<<endl;
  //we are comparing strings to see whether they will fall under the if or else part of the //if-else statement
  else 
  cout<<"\n\nThank you so much for your review! We are always looking for ways to \nimprove and better the service for our customers! We have automatically added your review below\n"<<endl;
//there are two strings 
        cout<<"\n\nThe Authentic Burger and Bakery Restaurant\n-------------------------------------------\n            Customer Review(s)\n\n";
       cout<<"Very great food! And the service is very fast!\n\n";
       cout<<"The food is fresh and hot! The wait time is given and its very accurate\n\n";
       cout<<"Really packed restaurant, so try to get their on time to avoid wait!\n\n";
       cout<<"The scenic view outside is very beautiful and calming\n\n";
       cout<<"The burgers are the best! Never had such simple yet satisfying burger!\n\n";
       cout<<"Order the strawberry cheesecake for dessert! It's THE BEST!!\n\n";
       cout<< secondstring<<endl;
  return 0;
}