#include <iostream>
#include<iomanip>
#include<cmath>
using namespace std;
int main() {
int order;
//One option from the menu will take approximately 10 minutes
int ordering;
//use int variable to cout waiters line
  cout<<"Hello, My name is Dan and I will be taking your order\nHow many options will you be ordering, including dessert, beverages and main meal(s)?\n ";
  cin>>order;
  //use switch statement for each case of how many options the customers ill be ordering
switch(order){
  case(1):
   cout<<"To confirm, you are ordering one option from the menu"<<endl;
   cout<<"Please enter the food you will be ordering, including a main meal, beverage, or dessert and have each followed by a comma\n(Ex:Tapioca Pudding, Chocolate Milkshake, 2 Curly Fries)\n ";
   cin>>ordering;
   cout<<"\nThanks for ordering!\nYour food will ready in approximately 10-15 minutes!";
   //break the statement in the end so it does not cout the next statements
   break;
  case(2):
    //use switch statement for each case of how many options the customers ill be ordering
   cout<<"To confirm, you are ordering two options from the menu"<<endl;
   cout<<"Please enter the foods you will be ordering, including main meal(s), beverages, and dessert with each followed by a comma\n(Ex:Tapioca Pudding, Chocolate Milkshake, 2 Curly Fries)\n";
   cin>>ordering;
   cout<<"\nThanks for ordering!\nYour food will ready in approximately 20-25 minutes!";
   break;
     //use switch statement for each case of how many options the customers ill be ordering
   case(3):
   cout<<"To confirm, you are ordering three options from the menu\n"<<endl;
   cout<<"Please enter the foods you will be ordering, including main meal(s), beverages, and dessert with each followed by a comma\n(Ex:Tapioca Pudding, Chocolate Milkshake, 2 Curly Fries)\n";
   cin>>ordering;
   cout<<"\nThanks for ordering!\nYour food will ready in approximately 30-35 minutes!" ;
   break;
     //use switch statement for each case of how many options the customers ill be ordering
   case(4):
   cout<<"To confirm, you are ordering four options from the menu\n\n"<<endl;
   cout<<"Please enter the foods you will be ordering, including main meal(s), beverages, and dessert with each followed by a comma\n(Ex:Tapioca Pudding, Chocolate Milkshake, 2 Curly Fries)\n";
   cin>>ordering;
   cout<<"\nThanks for ordering!\nYour food will ready in approximately 35-40 minutes!" ;
   break;
     //use switch statement for each case of how many options the customers ill be ordering
   case(5):
   cout<<"To confirm, you are ordering five options from the menu\n\n"<<endl;
   cout<<"Please enter the foods you will be ordering, including main meal(s), beverages, and dessert with each followed by a comma\n(Ex:Tapioca Pudding, Chocolate Milkshake, 2 Curly Fries)\n";
   cin>>ordering;
   cout<<"\nThanks for ordering!\nYour food will ready in approximately 45-50 minutes!" ;
   
   break;
   //create a default statement so that no matter which case it is, customers are able to //enter foods they would like to order
   default:
   cout<<"Please enter the foods you will be ordering, including main meal(s), beverages, and dessert with each followed by a comma\n(Ex:Tapioca Pudding, Chocolate Milkshake, 2 Curly Fries)\n";
   cin>>ordering;
  cout<<"\nThanks for ordering! Your food will be ready soon!";


}
cout<<"\nMake sure you have inputted your ENTIRE order (Main Meal, Beverages, and Desserts),\nbesides a Build-your-Own Burger please!"<<endl; 
return 0;
}
