#include <iostream>
#include<cmath>
#include<iomanip>
using namespace std;
int main(){
  int choice;
  //we are using multiple if statements for each total that the user may
  //have for an accurate wait time for each party
  //The waiter is speaking to the customers
  cout<<"Hello! Welcome to the Authentic Burger and Bakery Restaurant!"<<endl;
  cout<<"";
  cout<<"Below is our seating menu. Which seat would you like?"<<endl;
  cout<<"Seating Area Choices"<<endl;
  cout<<"----------------------"<<endl;
  cout<<"1. Scenic Indoor View(Max:4 people) "<<endl;
  cout<<"2. Elegant Dining Table(No Limit) "<<endl;
  cout<<"3. Scenic Outdoor View(Max:5 people)"<<endl;
  cout<<"4. Comfy Couches(Max:4 or 8 people)"<<endl;
  cout<<"5. Corner High Chair Table(Max:6 people)"<<endl;
  cout<<"6. Anywhere(No Preference)"<<endl;
  //use for loop to allow user to enter in choice 

  int total;
  //the user will enter the amount dining today
  cout<<"\nHow many of you will be dining today? ";
  cin>>total;
  int name;
  //user enters the name of the party
  cout<<"\nPlease enter your name followed by your top three seating choices, each followed by a comma\n(Ex:Liz, 3, 5, 6)\n ";
  cin>>name;
//use if statements to provide a timing for the wait
  if (total>4)
  cout<<"\nGreat! Your wait time will be 20 minutes"<<endl;
//use if statement for greater than or less than
  if (total<4)
  cout<<"\nGreat! Your wait time will be 10 minutes"<<endl;
//if statement equals total
  if(total==4)
cout<<"\nGreat! Your wait time will be 8 minutes"<<endl;
cout<<"\nPlease take a seat in our waiting area and we will call you when one of your top three choices are opened! ";

  return 0;
}
