#include <iostream>
#include<iomanip>
#include<cmath>
using namespace std;
int main() {
int quantity;
int type;
cout<<"Greetings,my name is Dan, and I will take your burger order.\nHow many burgers will you be ordering today? ";
cin>> quantity;
cout<<"\nNow, I will ask you to input the items to build your burger.\n\nPlease input each with your choice followed by a comma:\nEx: Vegan, Lettuce, Tomato, Onion, Mayonnaise, Ketchup, Hot Sauce";

cout<<"\n\nNow, what type of burger meat, dressings, and toppings would you like?\n";
cin>>type;

//User will input type, toppings, and dressings of their choice
//Set precision to 4 so decimals are only in US Cash Form (ex $1.99)
float price;
//With math, do price = quantity*8.99, making 8.99 the price of each burger no matter the //toppings/dressings/meat chosen 
price = 8.99*quantity;
cout<<"\nThank you for your order! Your total will be $"<<setprecision(4)<<price<<" without tax"<<endl; 
int time;
time = 6 * quantity;
cout<<"\nYour order should be ready in "<<time<<" minutes or less!";
cout<<"\n\nIf you would like to order dessert, please visit our Main Menu\n to view choices and input an order!"<<endl;
return 0;
}

